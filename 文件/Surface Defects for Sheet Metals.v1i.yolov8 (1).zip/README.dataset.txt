# Surface Defects for Sheet Metals > 2026-08-27 7:35pm
https://universe.roboflow.com/zrong-liu/surface-defects-for-sheet-metals-unn0n

Provided by a Roboflow user
License: CC BY 4.0

